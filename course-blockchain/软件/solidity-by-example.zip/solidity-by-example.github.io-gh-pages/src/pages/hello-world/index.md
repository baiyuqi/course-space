---
title: Hello World
version: 0.8.10
description: Hello world in Solidity
---

`pragma` specifies the compiler version of Solidity.

```solidity
{{{HelloWorld}}}
```
