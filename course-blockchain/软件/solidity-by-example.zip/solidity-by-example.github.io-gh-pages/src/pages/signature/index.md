---
title: Verifying Signature
version: 0.8.10
description: An example of how to verify signatures in Solidity
---

Messages can be signed off chain and then verified on chain using a smart contract.

```solidity
{{{Signature}}}
```
