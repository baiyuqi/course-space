---
title: Ether Wallet
version: 0.8.10
description: Simple example of wallet in Solidity
---

An example of a basic wallet.

- Anyone can send ETH.
- Only the owner can withdraw.

```solidity
{{{EtherWallet}}}
```
