---
title: ERC721
version: 0.8.10
description: Example of ERC721 non fungible token in Solidity
---

Example of ERC721

```solidity
{{{ERC721}}}
```
