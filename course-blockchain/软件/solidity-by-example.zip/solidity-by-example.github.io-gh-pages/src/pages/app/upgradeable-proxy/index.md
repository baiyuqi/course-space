---
title: Upgradeable Proxy
version: 0.8.10
description: Example of upgradeable proxy
---

Example of upgradeable proxy contract. Never use this in production.

This example shows how to use `delegatecall` and return data when `fallback` is called.

```solidity
{{{UpgradeableProxy}}}
```
