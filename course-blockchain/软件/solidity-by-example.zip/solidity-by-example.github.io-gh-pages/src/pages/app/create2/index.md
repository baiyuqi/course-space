---
title: Precompute Contract Address with Create2
version: 0.8.10
description: Precompute contract address with create2
---

Contract address can be precomputed, before the contract is deployed, using `create2`

```solidity
{{{Create2}}}
```
