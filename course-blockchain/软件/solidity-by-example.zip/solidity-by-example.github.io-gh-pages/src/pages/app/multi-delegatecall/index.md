---
title: Multi Delegatecall
version: 0.8.10
description: An example of contract to call multiple functions in a single transaction
---

An example of calling multiple functions with a single transaction, using `delegatecall`.

```solidity
{{{MultiDelegatecall}}}
```
