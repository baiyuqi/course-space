---
title: Deploy Any Contract
version: 0.8.10
description: Deploy Any Contract
---

Deploy any contract by calling `Proxy.deploy(bytes memory _code)`

For this example, you can get the contract bytecodes by calling `Helper.getBytecode1` and `Helper.getBytecode2`

```solidity
{{{Proxy}}}
```
