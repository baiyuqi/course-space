---
title: Minimal Proxy Contract
version: 0.8.10
description: Deploy contracts cheaply with minimal proxy contract
---

If you have a contract that will be deployed multiple times, use minimal proxy contract to deploy them cheaply.

```solidity
{{{MinimalProxy}}}
```
