---
title: Payable
version: 0.8.10
description: An example of how to use the keyword payable in Solidity
---

Functions and addresses declared `payable` can receive `ether` into the contract.

```solidity
{{{Payable}}}
```
