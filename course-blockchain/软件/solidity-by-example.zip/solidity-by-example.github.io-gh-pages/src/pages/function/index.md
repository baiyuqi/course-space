---
title: Function
version: 0.8.10
description: Example of how to write functions in Solidity
---

There are several ways to return outputs from a function.

Public functions cannot accept certain data types as inputs or outputs

```solidity
{{{Function}}}
```
