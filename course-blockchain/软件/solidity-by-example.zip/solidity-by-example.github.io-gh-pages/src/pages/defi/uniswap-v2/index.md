---
title: Uniswap V2 Swap
version: 0.8.10
description: Uniswap V2 swap
---

### Swap

Swaps an exact amount of input tokens for as many output tokens as possible.

```solidity
{{{Swap}}}
```
