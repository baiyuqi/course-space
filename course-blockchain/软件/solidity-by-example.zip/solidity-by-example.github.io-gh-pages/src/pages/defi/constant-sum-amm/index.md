---
title: Constant Sum AMM
version: 0.8.10
description: Constant sum AMM
---

Constant sum AMM `X + Y = K`

Tokens trade one to one.

```solidity
{{{CSAMM}}}
```
