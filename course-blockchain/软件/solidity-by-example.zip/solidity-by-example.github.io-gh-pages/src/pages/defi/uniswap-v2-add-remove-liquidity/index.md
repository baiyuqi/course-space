---
title: Uniswap V2 Add Remove Liquidity
version: 0.8.10
description: Uniswap V2 add remove liquidity
---

### Add / Remove Liquidity

```solidity
{{{Liquidity}}}
```
