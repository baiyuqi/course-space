---
title: Uniswap V2 Optimal One Sided Supply
version: 0.8.10
description: Uniswap V2 Optimal One Sided Supply
---

### Optimal One Sided Supply

```solidity
{{{Optimal}}}
```
