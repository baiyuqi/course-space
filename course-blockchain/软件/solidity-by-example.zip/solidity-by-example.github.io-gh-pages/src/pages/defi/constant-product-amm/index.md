---
title: Constant Product AMM
version: 0.8.10
description: Constant product AMM
---

Constant product AMM `XY = K`

```solidity
{{{CPAMM}}}
```
