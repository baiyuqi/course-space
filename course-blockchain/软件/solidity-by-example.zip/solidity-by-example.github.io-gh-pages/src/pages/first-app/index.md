---
title: First Application
version: 0.8.10
description: Example of smart contract in Solidity
---

Here is a simple contract that you can get, increment and decrement the count store in this contract.

```solidity
{{{Counter}}}
```
