---
title: If / Else
version: 0.8.10
description: If / Else conditional statement in Solidity
---

Solidity supports conditional statements `if`, `else if` and `else`.

```solidity
{{{IfElse}}}
```
