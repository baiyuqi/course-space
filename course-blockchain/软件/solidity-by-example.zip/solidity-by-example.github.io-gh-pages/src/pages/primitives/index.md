---
title: Primitive Data Types
version: 0.8.10
description: Primitive data types
---

Here we introduce you to some primitive data types available in Solidity.

- `boolean`
- `uint`
- `int`
- `address`

```solidity
{{{Primitives}}}
```
