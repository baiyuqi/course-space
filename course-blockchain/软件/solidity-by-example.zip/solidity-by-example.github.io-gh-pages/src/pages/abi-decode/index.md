---
title: ABI Decode
version: 0.8.10
description: ABI decode bytes
---

`abi.encode` encodes data into `bytes`.

`abi.decode` decodes `bytes` back into data.

```solidity
{{{AbiDecode}}}
```
